export default class Extension {
    enable() { console.log('Enabled'); }
    disable() { console.log('Disabled'); }
}
